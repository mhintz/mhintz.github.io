source = open("example.txt")
dest = open("index.html", "w+")

## PART 1

# for line in source:
# 	if line[0] == "#":
# 		html = "<h1>" + line + "</h1>"
# 		dest.write(html)
# 	else:
# 		html = "<p>" + line + "</p>"
# 		dest.write(html)

## PART 2

# allLines = []

# for line in source:
# 	allLines.append(line)

# allLines.reverse()

# for line in allLines:
# 	if line[0] == "#":
# 		html = "<h1>" + line[1:] + "</h1>"
# 		dest.write(html)
# 	else:
# 		html = "<p>" + line + "</p>"
# 		dest.write(html)

## PART 3

# def processLine(textLine):
# 	if textLine[0] == "#":
# 		return "<h1>" + textLine[1:] + "</h1>"
# 	else:
# 		return "<p>" + textLine + "</p>"

# for line in source:
# 	processed = processLine(line)
# 	dest.write(processed)

## PART 4

def processLine(textLine):
	if textLine[0] == "#":
		return "<h1>" + textLine[1:] + "</h1>"
	elif textLine[0] == "$":
		return "<p class='indented'>" + textLine[1:] + "</p>"
	else:
		return "<p>" + textLine + "</p>"

style = """
<link href='style.css' rel='stylesheet'>
"""

dest.write(style)

for line in source:
	dest.write(processLine(line))

